package com.group.smarthome.utils;

public class RegistCheck {
    private String pswCons;
    private String userExist;
    private String registerState;

    public String getPswCons() {
        return pswCons;
    }

    public void setPswCons(String pswCons) {
        this.pswCons = pswCons;
    }

    public String getUserExist() {
        return userExist;
    }

    public void setUserExist(String userExist) {
        this.userExist = userExist;
    }

    public String getRegisterState() {
        return registerState;
    }

    public void setRegisterState(String registerState) {
        this.registerState = registerState;
    }

    @Override
    public String toString() {
        return "RegistCheck{"+pswCons+" "+userExist+" "+registerState+"}";
    }
}
